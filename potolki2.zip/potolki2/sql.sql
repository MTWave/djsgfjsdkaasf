CREATE DATABASE IF NOT EXISTS potolki_pro;
USE potolki_pro;

CREATE TABLE IF NOT EXISTS orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(255) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    material VARCHAR(100) NOT NULL,
    area DECIMAL(10,2) NOT NULL,
    address TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status ENUM('new', 'processed', 'completed') DEFAULT 'new'
);