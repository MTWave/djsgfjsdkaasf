<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Подвесные потолки для офисов | ПотолкиПро</title>
    <meta name="description" content="Производство и монтаж подвесных потолков">
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
    
    <style>
        .navbar-brand { font-weight: bold; font-size: 1.5rem; }
        .hero-section {
            background: linear-gradient(rgba(0,0,0,0.7), rgba(0,0,0,0.7)), url('https://images.unsplash.com/photo-1565008447742-97f6f30c9b8f?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80');
            background-size: cover; 
            color: white; 
            padding: 150px 0; 
            margin-bottom: 50px;
            background-position: center;
        }
        .service-card { transition: transform 0.3s; height: 100%; }
        .service-card:hover { transform: translateY(-10px); }
        .content-section { min-height: 60vh; padding: 50px 0; }
        .active-nav { color: #0d6efd !important; font-weight: bold; }
    </style>
</head>
<body>
    <!-- Навигация -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm fixed-top">
        <div class="container">
            <a class="navbar-brand" href="#" data-page="home">
                <i class="bi bi-building"></i> ПотолкиПро
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="#" data-page="home">Главная</a></li>
                    <li class="nav-item"><a class="nav-link" href="#" data-page="about">О компании</a></li>
                    <li class="nav-item"><a class="nav-link" href="#" data-page="services">Услуги</a></li>
                    <li class="nav-item"><a class="nav-link" href="#" data-page="portfolio">Портфолио</a></li>
                    <li class="nav-item"><a class="nav-link" href="#" data-page="order">Заказать</a></li>
                    <li class="nav-item"><a class="nav-link" href="#" data-page="contacts">Контакты</a></li>
                    <li class="nav-item">
                        <a class="nav-link" href="admin_login.php" target="_blank">
                            <i class="bi bi-lock"></i> Админ
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Контейнер для контента -->
    <div id="content-container">
        <!-- Контент загружается динамически -->
    </div>

    <!-- Подвал -->
    <footer class="bg-dark text-white py-4 mt-5">
        <div class="container text-center">
            <p>&copy; 2025 ПотолкиПро. Все права защищены.</p>
        </div>
    </footer>

    <!-- Модальное окно для уведомлений -->
    <div class="modal fade" id="messageModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Уведомление</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body" id="messageModalBody"></div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // Страницы сайта
        const pages = {
            home: {
                title: "Главная | ПотолкиПро",
                content: `
                    <section class="hero-section">
                        <div class="container">
                            <h1 class="display-4">Подвесные потолки для офисов</h1>
                            <p class="lead">Производство и монтаж</p>
                            <a href="#" class="btn btn-primary btn-lg" data-page="order">Получить консультацию</a>
                        </div>
                    </section>
                    
                    <div class="container content-section">
                        <div class="row">
                            <div class="col-md-6">
                                <h2>Наши преимущества</h2>
                                <ul class="list-group list-group-flush">
                                    <li class="list-group-item"><i class="bi bi-check-circle-fill text-primary me-2"></i>15 лет опыта</li>
                                    <li class="list-group-item"><i class="bi bi-check-circle-fill text-primary me-2"></i>500+ проектов</li>
                                    <li class="list-group-item"><i class="bi bi-check-circle-fill text-primary me-2"></i>Гарантия 5 лет</li>
                                    <li class="list-group-item"><i class="bi bi-check-circle-fill text-primary me-2"></i>Собственное производство</li>
                                </ul>
                            </div>
                            <div class="col-md-6">
                                <img src="https://images.unsplash.com/photo-1565008447742-97f6f30c9b8f?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80" alt="Потолки" class="img-fluid rounded">
                            </div>
                        </div>
                    </div>
                `
            },
            
            about: {
                title: "О компании | ПотолкиПро",
                content: `
                    <div class="container content-section">
                        <h1>О компании</h1>
                        <div class="row">
                            <div class="col-md-8">
                                <p class="lead">Компания "ПотолкиПро" работает с 2008 года.</p>
                                <p>Специализируемся на производстве и монтаже подвесных потолков для офисов. За 15 лет работы мы реализовали более 500 проектов различной сложности.</p>
                                <p>Наша команда состоит из опытных специалистов, которые знают все тонкости монтажа подвесных потолков. Мы используем только качественные материалы и современное оборудование.</p>
                            </div>
                            <div class="col-md-4">
                                <div class="card">
                                    <div class="card-body">
                                        <h5 class="card-title">Наши сертификаты</h5>
                                        <ul class="list-unstyled">
                                            <li><i class="bi bi-file-text text-primary me-2"></i>Лицензия Минстроя</li>
                                            <li><i class="bi bi-file-text text-primary me-2"></i>Сертификат ISO 9001</li>
                                            <li><i class="bi bi-file-text text-primary me-2"></i>СРО на монтаж</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                `
            },
            
            services: {
                title: "Услуги | ПотолкиПро",
                content: `
                    <div class="container content-section">
                        <h1 class="mb-4">Наши услуги</h1>
                        <div class="row">
                            <div class="col-md-4 mb-4">
                                <div class="card service-card">
                                    <img src="https://images.unsplash.com/photo-1565008447742-97f6f30c9b8f?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80" class="card-img-top" alt="Armstrong">
                                    <div class="card-body">
                                        <h3>Потолки Armstrong</h3>
                                        <p>Монтаж модульных потолков армстронг. Быстро и качественно.</p>
                                        <p class="h5 text-primary">От 850 ₽/м²</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4 mb-4">
                                <div class="card service-card">
                                    <img src="https://images.unsplash.com/photo-1593642532973-d31b6557fa68?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80" class="card-img-top" alt="Гипсокартон">
                                    <div class="card-body">
                                        <h3>Гипсокартонные</h3>
                                        <p>Сложные многоуровневые конструкции любой сложности.</p>
                                        <p class="h5 text-primary">От 1200 ₽/м²</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4 mb-4">
                                <div class="card service-card">
                                    <img src="https://images.unsplash.com/photo-1584622781564-1d987f7333c1?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80" class="card-img-top" alt="Реечные">
                                    <div class="card-body">
                                        <h3>Реечные</h3>
                                        <p>Для помещений с повышенной влажностью. Алюминиевые рейки.</p>
                                        <p class="h5 text-primary">От 950 ₽/м²</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                `
            },
            
            portfolio: {
                title: "Портфолио | ПотолкиПро",
                content: `
                    <div class="container content-section">
                        <h1 class="mb-4">Наши работы</h1>
                        <div class="row">
                            <div class="col-md-4 mb-4">
                                <div class="card">
                                    <img src="https://images.unsplash.com/photo-1497366754035-f200968a6e72?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80" class="card-img-top" alt="Проект 1">
                                    <div class="card-body">
                                        <h5 class="card-title">Офисный центр "Плаза"</h5>
                                        <p class="card-text">Потолки Armstrong, 450 м²</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4 mb-4">
                                <div class="card">
                                    <img src="https://images.unsplash.com/photo-1497366811353-6870744d04b2?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80" class="card-img-top" alt="Проект 2">
                                    <div class="card-body">
                                        <h5 class="card-title">Бизнес-центр "Москва"</h5>
                                        <p class="card-text">Многоуровневые гипсокартонные потолки, 320 м²</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4 mb-4">
                                <div class="card">
                                    <img src="https://images.unsplash.com/photo-1497366216548-37526070297c?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80" class="card-img-top" alt="Проект 3">
                                    <div class="card-body">
                                        <h5 class="card-title">Торговый центр "Ритэйл"</h5>
                                        <p class="card-text">Реечные потолки, 280 м²</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                `
            },
            
            order: {
                title: "Заказать потолок | ПотолкиПро",
                content: `
                    <div class="container content-section">
                        <div class="row justify-content-center">
                            <div class="col-md-8">
                                <h1 class="mb-4">Заказать подвесной потолок</h1>
                                
                                <div id="orderMessage" style="display: none;" class="alert"></div>
                                
                                <form id="orderForm" class="needs-validation" novalidate>
                                    <div class="mb-3">
                                        <label for="full_name" class="form-label">ФИО *</label>
                                        <input type="text" class="form-control" id="full_name" name="full_name" required>
                                        <div class="invalid-feedback">Укажите ваше ФИО</div>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="phone" class="form-label">Телефон *</label>
                                        <input type="tel" class="form-control" id="phone" name="phone" required 
                                               placeholder="+7 (999) 123-45-67">
                                        <div class="invalid-feedback">Укажите корректный номер телефона</div>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="material" class="form-label">Материал потолка *</label>
                                        <select class="form-select" id="material" name="material" required>
                                            <option value="">Выберите материал</option>
                                            <option value="armstrong">Armstrong (модульный)</option>
                                            <option value="gipsokarton">Гипсокартонный</option>
                                            <option value="reechniy">Реечный</option>
                                            <option value="kassetniy">Кассетный</option>
                                            <option value="grilyato">Грильято</option>
                                        </select>
                                        <div class="invalid-feedback">Выберите материал потолка</div>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="area" class="form-label">Площадь помещения (м²) *</label>
                                        <input type="number" class="form-control" id="area" name="area" required 
                                               min="1" step="0.1" value="10">
                                        <div class="invalid-feedback">Укажите площадь помещения</div>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="address" class="form-label">Адрес работ *</label>
                                        <textarea class="form-control" id="address" name="address" rows="3" required></textarea>
                                        <div class="invalid-feedback">Укажите адрес</div>
                                    </div>
                                    
                                    <button type="submit" class="btn btn-primary btn-lg">Отправить заказ</button>
                                </form>
                            </div>
                        </div>
                    </div>
                `
            },
            
            contacts: {
                title: "Контакты | ПотолкиПро",
                content: `
                    <div class="container content-section">
                        <h1 class="mb-4">Контакты</h1>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="card">
                                    <div class="card-body">
                                        <h3 class="card-title">Наши контакты</h3>
                                        <ul class="list-unstyled">
                                            <li class="mb-3"><i class="bi bi-telephone-fill text-primary me-2"></i> <strong>Телефон:</strong> +7 (495) 123-45-67</li>
                                            <li class="mb-3"><i class="bi bi-envelope-fill text-primary me-2"></i> <strong>Email:</strong> info@potolkipro.ru</li>
                                            <li class="mb-3"><i class="bi bi-geo-alt-fill text-primary me-2"></i> <strong>Адрес:</strong> г. Москва, ул. Уличная, д. 15</li>
                                            <li class="mb-3"><i class="bi bi-clock-fill text-primary me-2"></i> <strong>Режим работы:</strong> Пн-Пт 9:00-18:00</li>
                                        </ul>
                                        <a href="#" class="btn btn-primary mt-3" data-page="order">Заказать звонок</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="card">
                                    <div class="card-body">
                                        <h3 class="card-title">Схема проезда</h3>
                                        <div class="bg-light p-3 text-center">
                                            <i class="bi bi-map" style="font-size: 3rem;"></i>
                                            <p class="mt-2">м. Комсомольская, выход №3, 5 минут пешком</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                `
            }
        };

        // Показ сообщения
        function showMessage(text, type = 'info') {
            const modalBody = document.getElementById('messageModalBody');
            const modal = new bootstrap.Modal(document.getElementById('messageModal'));
            
            modalBody.innerHTML = `<div class="alert alert-${type} mb-0">${text}</div>`;
            modal.show();
        }

        // Обработка отправки формы заказа
        function handleOrderSubmit(e) {
            e.preventDefault();
            
            const form = document.getElementById('orderForm');
            const messageDiv = document.getElementById('orderMessage');
            
            // Валидация
            if (!form.checkValidity()) {
                e.stopPropagation();
                form.classList.add('was-validated');
                return;
            }
            
            // Собираем данные формы
            const formData = new FormData(form);
            
            // Отправляем на сервер
            fetch('submit_order.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                messageDiv.style.display = 'block';
                messageDiv.className = `alert alert-${data.success ? 'success' : 'danger'}`;
                messageDiv.textContent = data.message;
                
                if (data.success) {
                    form.reset();
                    form.classList.remove('was-validated');
                    
                    // Через 5 секунд скрываем сообщение
                    setTimeout(() => {
                        messageDiv.style.display = 'none';
                    }, 5000);
                }
            })
            .catch(error => {
                messageDiv.style.display = 'block';
                messageDiv.className = 'alert alert-danger';
                messageDiv.textContent = 'Ошибка при отправке заказа';
            });
        }

        // Загрузка страницы
        function loadPage(page = 'home') {
            if (!pages[page]) {
                page = 'home';
            }
            
            document.title = pages[page].title;
            document.getElementById('content-container').innerHTML = pages[page].content;
            
            // Обновляем активный пункт меню
            document.querySelectorAll('.nav-link').forEach(link => {
                link.classList.remove('active-nav');
                if (link.getAttribute('data-page') === page) {
                    link.classList.add('active-nav');
                }
            });
            
            window.scrollTo(0, 0);
            
            // Инициализируем обработчик формы заказа
            if (page === 'order') {
                const form = document.getElementById('orderForm');
                if (form) {
                    form.addEventListener('submit', handleOrderSubmit);
                }
            }
        }

        // Обработка кликов по навигации
        document.addEventListener('click', (e) => {
            const link = e.target.closest('[data-page]');
            if (link) {
                e.preventDefault();
                const page = link.getAttribute('data-page');
                loadPage(page);
            }
        });

        // Загружаем главную страницу при старте
        loadPage('home');
    </script>
</body>
</html>