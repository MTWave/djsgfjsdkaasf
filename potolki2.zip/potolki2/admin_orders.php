<?php
// admin_orders.php
session_start();
require_once 'config.php';

// Проверка авторизации
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: admin_login.php');
    exit;
}

// Обновление статуса заказа
if (isset($_POST['update_status'])) {
    $order_id = $_POST['order_id'];
    $status = $_POST['status'];
    
    $stmt = $pdo->prepare("UPDATE orders SET status = ? WHERE id = ?");
    $stmt->execute([$status, $order_id]);
    
    header('Location: admin_orders.php');
    exit;
}

// Получение всех заказов
$orders = $pdo->query("SELECT * FROM orders ORDER BY created_at DESC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Админ-панель - Заказы</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
</head>
<body>
    <nav class="navbar navbar-dark bg-dark">
        <div class="container">
            <span class="navbar-brand">Админ-панель - Управление заказами</span>
            <a href="admin_logout.php" class="btn btn-outline-light">Выйти</a>
        </div>
    </nav>
    
    <div class="container mt-4">
        <h2 class="mb-4">Список заказов</h2>
        
        <?php if (empty($orders)): ?>
            <div class="alert alert-info">Заказов пока нет</div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-striped table-hover">
                    <thead class="table-dark">
                        <tr>
                            <th>ID</th>
                            <th>Дата</th>
                            <th>ФИО</th>
                            <th>Телефон</th>
                            <th>Материал</th>
                            <th>Площадь</th>
                            <th>Адрес</th>
                            <th>Статус</th>
                            <th>Действия</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($orders as $order): ?>
                        <tr>
                            <td><?= $order['id'] ?></td>
                            <td><?= date('d.m.Y H:i', strtotime($order['created_at'])) ?></td>
                            <td><?= htmlspecialchars($order['full_name']) ?></td>
                            <td><?= htmlspecialchars($order['phone']) ?></td>
                            <td>
                                <?php
                                $materials = [
                                    'armstrong' => 'Armstrong',
                                    'gipsokarton' => 'Гипсокартон',
                                    'reechniy' => 'Реечный',
                                    'kassetniy' => 'Кассетный',
                                    'grilyato' => 'Грильято'
                                ];
                                echo $materials[$order['material']] ?? $order['material'];
                                ?>
                            </td>
                            <td><?= $order['area'] ?> м²</td>
                            <td><?= htmlspecialchars($order['address']) ?></td>
                            <td>
                                <?php
                                $status_classes = [
                                    'new' => 'danger',
                                    'processed' => 'warning',
                                    'completed' => 'success'
                                ];
                                $status_text = [
                                    'new' => 'Новый',
                                    'processed' => 'В обработке',
                                    'completed' => 'Выполнен'
                                ];
                                ?>
                                <span class="badge bg-<?= $status_classes[$order['status']] ?>">
                                    <?= $status_text[$order['status']] ?>
                                </span>
                            </td>
                            <td>
                                <form method="POST" class="d-inline">
                                    <input type="hidden" name="order_id" value="<?= $order['id'] ?>">
                                    <select name="status" class="form-select form-select-sm d-inline w-auto">
                                        <option value="new" <?= $order['status'] == 'new' ? 'selected' : '' ?>>Новый</option>
                                        <option value="processed" <?= $order['status'] == 'processed' ? 'selected' : '' ?>>В обработке</option>
                                        <option value="completed" <?= $order['status'] == 'completed' ? 'selected' : '' ?>>Выполнен</option>
                                    </select>
                                    <button type="submit" name="update_status" class="btn btn-sm btn-primary">
                                        <i class="bi bi-check"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>