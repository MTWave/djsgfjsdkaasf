<?php
// submit_order.php
header('Content-Type: application/json; charset=utf-8');
require_once 'config.php';

// Получаем данные из POST запроса
$full_name = $_POST['full_name'] ?? '';
$phone = $_POST['phone'] ?? '';
$material = $_POST['material'] ?? '';
$area = $_POST['area'] ?? '';
$address = $_POST['address'] ?? '';

// Валидация
$errors = [];

if (empty($full_name)) {
    $errors[] = 'Укажите ФИО';
}

if (empty($phone)) {
    $errors[] = 'Укажите телефон';
}

if (empty($material)) {
    $errors[] = 'Выберите материал';
}

if (empty($area) || !is_numeric($area) || $area <= 0) {
    $errors[] = 'Укажите корректную площадь';
}

if (empty($address)) {
    $errors[] = 'Укажите адрес';
}

if (!empty($errors)) {
    echo json_encode([
        'success' => false, 
        'message' => implode(', ', $errors)
    ]);
    exit;
}

try {
    // Подготавливаем SQL запрос
    $sql = "INSERT INTO orders (full_name, phone, material, area, address) 
            VALUES (:full_name, :phone, :material, :area, :address)";
    
    $stmt = $pdo->prepare($sql);
    
    // Выполняем запрос
    $result = $stmt->execute([
        ':full_name' => $full_name,
        ':phone' => $phone,
        ':material' => $material,
        ':area' => $area,
        ':address' => $address
    ]);
    
    if ($result) {
        echo json_encode([
            'success' => true, 
            'message' => 'Заказ успешно отправлен! Мы свяжемся с вами в ближайшее время.'
        ]);
    } else {
        echo json_encode([
            'success' => false, 
            'message' => 'Ошибка при сохранении заказа'
        ]);
    }
    
} catch(PDOException $e) {
    echo json_encode([
        'success' => false, 
        'message' => 'Ошибка базы данных: ' . $e->getMessage()
    ]);
}
?>