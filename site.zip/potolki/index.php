<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Подвесные потолки для офисов | ПотолкиПро</title>
    <meta name="description" content="Производство и монтаж подвесных потолков">
    <meta name="keywords" content="Потолки, монтаж подвесных потолков, подвесные потолки">
    
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
    
    <style>
        .navbar-brand { font-weight: bold; font-size: 1.5rem; }
        .hero-section {
            background: linear-gradient(rgba(0,0,0,0.7), rgba(0,0,0,0.7)), url('');
            background-size: cover; color: white; padding: 150px 0; margin-bottom: 50px;
        }
        .service-card { transition: transform 0.3s; height: 100%; }
        .service-card:hover { transform: translateY(-10px); }
        .portfolio-img { height: 250px; object-fit: cover; width: 100%; }
        .content-section { min-height: 60vh; padding: 50px 0; }
        .active-nav { color: #0d6efd !important; font-weight: bold; }
    </style>
</head>
<body>
    <!--навигация -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm fixed-top">
        <div class="container">
            <a class="navbar-brand" href="#home" data-page="home">
                <i class="bi bi-building"></i> ПотолкиПро
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="#home" data-page="home">Главная</a></li>
                    <li class="nav-item"><a class="nav-link" href="#about" data-page="about">О компании</a></li>
                    <li class="nav-item"><a class="nav-link" href="#services" data-page="services">Услуги</a></li>
                    <li class="nav-item"><a class="nav-link" href="#portfolio" data-page="portfolio">Портфолио</a></li>
                    <li class="nav-item"><a class="nav-link" href="#contacts" data-page="contacts">Контакты</a></li>
                    <li class="nav-item">
                        <button class="btn btn-primary ms-2" data-bs-toggle="modal" data-bs-target="#contactModal">
                            Написать нам
                        </button>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Контейнер для контента -->
    <div id="content-container">
        <!-- Контент загружается динамически -->
    </div>

    <footer class="bg-dark text-white py-4 mt-5">
        <div class="container text-center">
            <p>&copy; 2025 ПотолкиПро.</p>
        </div>
    </footer>

    <div class="modal fade" id="contactModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Написать нам</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form id="contactForm" action="submit_form.php" method="POST">
                        <div class="mb-3">
                            <label for="name" class="form-label">Имя *</label>
                            <input type="text" class="form-control" id="name" name="name" required>
                        </div>
                        <div class="mb-3">
                            <label for="phone" class="form-label">Телефон *</label>
                            <input type="tel" class="form-control" id="phone" name="phone" required>
                        </div>
                        <div class="mb-3">
                            <label for="email" class="form-label">Email *</label>
                            <input type="email" class="form-control" id="email" name="email" required>
                        </div>
                        <div class="mb-3">
                            <label for="message" class="form-label">Сообщение</label>
                            <textarea class="form-control" id="message" name="message" rows="3"></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary">Отправить</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="bootstrap/js/bootstrap.bundle.min.js"></script>
    
    <script>
        const pages = {
            home: {
                title: "Главная | ПотолкиПро",
                content: `
                    <section class="hero-section">
                        <div class="container">
                            <h1 class="display-4">Подвесные потолки для офисов</h1>
                            <p class="lead">Производство и монтаж</p>
                            <button class="btn btn-primary btn-lg" data-bs-toggle="modal" data-bs-target="#contactModal">
                                Получить консультацию
                            </button>
                        </div>
                    </section>
                    
                    <div class="container content-section">
                        <div class="row">
                            <div class="col-md-6">
                                <h2>Наши преимущества</h2>
                                <ul>
                                    <li>15 лет опыта</li>
                                    <li>500+ проектов</li>
                                    <li>Гарантия 5 лет</li>
                                    <li>Собственное производство</li>
                                </ul>
                            </div>
                            <div class="col-md-6">
                                <img src="images/potolki1.jpg" alt="Потолки" class="img-fluid rounded">
                            </div>
                        </div>
                    </div>
                `
            },
            
            about: {
                title: "О компании | ПотолкиПро",
                content: `
                    <div class="container content-section">
                        <h1>О компании</h1>
                        <p>Компания "ПотолкиПро" работает с 2008 года.</p>
                        <p>Специализируемся на производстве и монтаже подвесных потолков для офисов.</p>
                    </div>
                `
            },
            
            services: {
                title: "Услуги | ПотолкиПро",
                content: `
                    <div class="container content-section">
                        <h1>Наши услуги</h1>
                        <div class="row">
                            <div class="col-md-4 mb-4">
                                <div class="card">
                                    <div class="card-body">
                                        <h3>Потолки Armstrong</h3>
                                        <p>Монтаж модульных потолков</p>
                                        <p><strong>От 850 ₽/м²</strong></p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4 mb-4">
                                <div class="card">
                                    <div class="card-body">
                                        <h3>Гипсокартонные</h3>
                                        <p>Сложные многоуровневые конструкции</p>
                                        <p><strong>От 1200 ₽/м²</strong></p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4 mb-4">
                                <div class="card">
                                    <div class="card-body">
                                        <h3>Реечные</h3>
                                        <p>Для помещений с повышенной влажностью</p>
                                        <p><strong>От 950 ₽/м²</strong></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                `
            },
            
            portfolio: {
                title: "Портфолио | ПотолкиПро",
                content: `
                    <div class="container content-section">
                        <h1>Наши работы</h1>
                        <div class="row">
                            <div class="col-md-4 mb-4">
                                <img src="images/office_center.jpg" class="img-fluid rounded" alt="Проект 1">
                                <h5 class="mt-2">Офисный центр</h5>
                            </div>
                            <div class="col-md-4 mb-4">
                                <img src="images/shtab_kvartira.jpeg" class="img-fluid rounded" alt="Проект 2">
                                <h5 class="mt-2">Штаб-квартира</h5>
                            </div>
                        </div>
                    </div>
                `
            },
            
            contacts: {
                title: "Контакты | ПотолкиПро",
                content: `
                    <div class="container content-section">
                        <h1>Контакты</h1>
                        <div class="row">
                            <div class="col-md-6">
                                <h3>Наши контакты</h3>
                                <p><strong>Телефон:</strong> +7 (495) 123-45-67</p>
                                <p><strong>Email:</strong> info@potolkipro.ru</p>
                                <p><strong>Адрес:</strong> г. Москва, ул. Уличная, д. 15</p>
                                <button class="btn btn-primary mt-3" data-bs-toggle="modal" data-bs-target="#contactModal">
                                    Написать нам
                                </button>
                            </div>
                        </div>
                    </div>
                `
            }
        };

        function loadPage(page = 'home') {
            document.title = pages[page].title;
            document.getElementById('content-container').innerHTML = pages[page].content;
            
            document.querySelectorAll('.nav-link').forEach(link => {
                link.classList.remove('active-nav');
                if (link.getAttribute('data-page') === page) {
                    link.classList.add('active-nav');
                }
            });
            
            window.scrollTo(0, 0);
        }

        document.addEventListener('click', (e) => {
            if (e.target.closest('.nav-link')) {
                e.preventDefault();
                const page = e.target.closest('.nav-link').getAttribute('data-page');
                loadPage(page);
            }
        });

        loadPage('home');
    </script>
</body>
</html>