<?php
// Простой обработчик формы для учебного проекта

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Получаем данные из формы
    $name = $_POST['name'] ?? '';
    $phone = $_POST['phone'] ?? '';
    $email = $_POST['email'] ?? '';
    $message = $_POST['message'] ?? '';
    
    // Простая валидация
    $errors = [];
    
    if (empty($name)) $errors[] = 'Введите имя';
    if (empty($phone)) $errors[] = 'Введите телефон';
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Введите корректный email';
    }
    
    if (empty($errors)) {
        // Подключение к базе данных (упрощенное)
        $host = 'localhost';
        $user = 'root'; // стандартный пользователь XAMPP
        $pass = ''; // стандартный пароль XAMPP
        $dbname = 'potolki';
        
        // Создаем подключение
        $conn = new mysqli($host, $user, $pass, $dbname);
        
        if ($conn->connect_error) {
            die("Ошибка подключения: " . $conn->connect_error);
        }
        
        // Подготавливаем запрос
        $stmt = $conn->prepare("INSERT INTO заявки (name, phone, email, message, created_at) VALUES (?, ?, ?, ?, NOW())");
        $stmt->bind_param("ssss", $name, $phone, $email, $message);
        
        if ($stmt->execute()) {
            echo "<div class='alert alert-success'>Заявка успешно отправлена!</div>";
            
            // Также можно вывести данные для проверки
            echo "<div class='mt-3 p-3 border rounded'>
                    <h5>Данные заявки:</h5>
                    <p><strong>Имя:</strong> $name</p>
                    <p><strong>Телефон:</strong> $phone</p>
                    <p><strong>Email:</strong> $email</p>
                    <p><strong>Сообщение:</strong> $message</p>
                    <p><small>Заявка сохранена в базе данных</small></p>
                  </div>";
        } else {
            echo "<div class='alert alert-danger'>Ошибка при сохранении: " . $conn->error . "</div>";
        }
        
        $stmt->close();
        $conn->close();
        
    } else {
        // Выводим ошибки
        echo "<div class='alert alert-danger'><ul>";
        foreach ($errors as $error) {
            echo "<li>$error</li>";
        }
        echo "</ul></div>";
    }
    
    // Кнопка назад
    echo "<a href='index.php' class='btn btn-primary mt-3'>Вернуться на сайт</a>";
    
} else {
    echo "<div class='alert alert-warning'>Неверный метод запроса</div>";
    echo "<a href='index.php' class='btn btn-primary mt-3'>На главную</a>";
}
?>